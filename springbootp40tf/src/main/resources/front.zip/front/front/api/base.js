﻿const base = {
    url : "http://localhost:8080/springbootp40tf/"
}
export default base
